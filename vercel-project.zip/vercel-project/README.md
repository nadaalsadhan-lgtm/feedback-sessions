# Client Feedback Sessions

## Deploy to Vercel

### 1. Add your Anthropic API key

In your Vercel project dashboard:
- Go to **Settings → Environment Variables**
- Add: `ANTHROPIC_API_KEY` = `sk-ant-...your key...`

### 2. Project structure

```
/
├── api/
│   └── claude.js        ← Server-side proxy (keeps API key secret)
├── public/
│   └── index.html       ← The app
└── vercel.json
```

### 3. How it works

The browser calls `/api/claude` (your own Vercel server).
The server adds your API key and forwards to `api.anthropic.com`.
No API key is ever exposed to the browser.

### 4. Get an API key

https://console.anthropic.com
